{
	'name':'new estate extend',
	'application':True,
	'category':'sales',
	'data':[
		'views/extend_menu.xml',
		'views/extend_view.xml',
		'security/ir.model.access.csv',
	    ],
	'license':'LGPL-3',
	
}
