{
    'name': 'new_Real Estate_',
    'application': True,
    'installble':True,
    'data': [
        'security/ir.model.access.csv',
        'views/estate_menu.xml',
        'views/estate_view.xml',
        'wizard/property_view.xml',
        ],
    'license':'LGPL-3',
}
